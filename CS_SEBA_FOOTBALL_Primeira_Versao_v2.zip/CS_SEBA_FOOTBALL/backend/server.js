// Exemplo mínimo de backend Node.js/Express.
// Este arquivo é um esqueleto de integração, NÃO um gateway de pagamento funcional.
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

const app = express();
app.use(helmet());
app.use(express.json({ limit: "100kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 60 }));

app.get("/health", (_req, res) => res.json({ ok: true, app: "CS SEBA FOOTBALL" }));

// O servidor deve criar uma transação pendente e iniciar o pagamento
// usando credenciais emitidas pelo banco/gateway autorizado.
// Não aceitar preço, estado de pagamento ou estado VIP confiados ao navegador.
app.post("/api/vip/checkout", async (req, res) => {
  // TODO: autenticar utilizador, validar plano no banco e criar transação pendente.
  // TODO: chamar API oficial do gateway (EMIS/banco ou parceiro contratado).
  // TODO: devolver apenas URL/QR/referência de pagamento permitidos pelo fornecedor.
  res.status(501).json({
    error: "Integração Multicaixa Express ainda não configurada.",
    nextStep: "Obter credenciais de comerciante e documentação do gateway."
  });
});

// Endpoint de webhook: verificar assinatura/autenticidade segundo a documentação
// do gateway antes de actualizar a transação e activar a assinatura.
app.post("/api/payments/multicaixa/webhook", async (_req, res) => {
  res.status(501).json({ error: "Webhook ainda não configurado." });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`CS SEBA FOOTBALL API em ${port}`));
