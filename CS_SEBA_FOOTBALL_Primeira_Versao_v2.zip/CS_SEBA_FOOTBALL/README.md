# CS SEBA FOOTBALL — primeira versão

## O que já funciona
- Site responsivo em português, com visual escuro/verde/dourado.
- Navegação entre Início, Análises, Estatísticas, Ao vivo e VIP.
- Conteúdo demonstrativo claramente identificado como fictício.
- Manifesto e service worker para instalação como PWA em Android (quando publicado em HTTPS).
- Esquema PostgreSQL inicial para utilizadores, jogos, análises, planos, assinaturas e pagamentos.
- Esqueleto de API Node.js para iniciar a futura integração de pagamentos.

## O que ainda NÃO está ligado
- Resultados e estatísticas reais.
- Login/contas persistentes.
- Pagamentos Multicaixa Express.
- Activação automática de VIP.
- Painel de administração.
- Publicação na Play Store.

## Testar o site
Abra `public/index.html` num navegador. Para testar instalação PWA/service worker, publique `public/` num servidor HTTPS. Em ambiente local, pode usar `python -m http.server 8080` dentro da pasta `public`, mas service workers exigem localhost ou HTTPS.

## Android
Opção rápida: publicar a PWA e permitir “Adicionar ao ecrã principal” no Chrome Android.
Para gerar APK nativo, depois de criar um projecto web com build estático:
1. Instale Node.js LTS e Android Studio.
2. `npm install @capacitor/core @capacitor/cli`
3. `npx cap init "CS SEBA FOOTBALL" ao.csseba.football`
4. Configure a pasta web (`webDir`) para a pasta publicada.
5. `npx cap add android`
6. `npx cap sync android`
7. `npx cap open android` e compile o APK no Android Studio.
A pasta atual é um protótipo HTML; pode ser embrulhada como PWA/WebView, mas precisa de configuração e testes antes de distribuição.

## Base de dados
O ficheiro `database/schema.sql` é o ponto de partida para PostgreSQL/Supabase. Antes de produção:
- activar Row Level Security (RLS) e políticas testadas;
- usar autenticação;
- separar permissões de utilizador, editor e administrador;
- nunca expor chaves privadas no navegador;
- guardar segredos apenas no servidor.

## Dados reais de futebol
Uma opção é API-Football: https://www.api-football.com/documentation_v3
A chave fica exclusivamente no backend. Verifique cobertura, preço, limites e direitos de uso dos dados para as competições pretendidas. Não mostre dados demonstrativos como dados reais.

## Multicaixa Express
O GPO é operado pela EMIS e disponibilizado a comerciantes através de bancos comerciais. Comece por falar com o seu banco e confirmar os requisitos de comerciante, taxas, documentação técnica e credenciais:
https://multicaixa.ao/pt/oferta/canais/comerciantes/gateway-de-pagamentos-online/
Alternativa de integração: AppyPay, sujeito a contrato e aprovação: https://www.appypay.co.ao/api-info

Fluxo obrigatório:
1. O backend valida o plano e cria uma transação `pending`.
2. O gateway/banco inicia o pagamento.
3. O utilizador confirma no canal oficial MCX Express.
4. O backend verifica a confirmação oficial/webhook ou consulta autenticada.
5. Só então o backend muda a transação para `confirmed` e activa a assinatura VIP.
Nunca pedir PIN bancário ao utilizador, nem activar VIP com base apenas num retorno do navegador.

## Próximos passos recomendados
1. Confirmar preços e duração dos planos VIP em AOA.
2. Criar conta de comerciante com banco/gateway.
3. Escolher fornecedor de dados e competições prioritárias.
4. Configurar Supabase/PostgreSQL e autenticação.
5. Implementar endpoints reais, painel admin, testes e política de privacidade/termos.
6. Publicar primeiro o site HTTPS e testar; depois gerar APK assinado.

## Aviso
Prognósticos são análises incertas, não garantias de ganhos. Inclua avisos de jogo responsável e cumpra as regras locais aplicáveis.
