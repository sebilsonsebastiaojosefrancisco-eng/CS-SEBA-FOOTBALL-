-- CS SEBA FOOTBALL — esquema inicial PostgreSQL/Supabase
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  phone text,
  role text not null default 'user' check (role in ('user','editor','admin')),
  created_at timestamptz not null default now()
);

create table if not exists plans (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  price_aoa integer not null check (price_aoa >= 0),
  duration_days integer not null check (duration_days > 0),
  active boolean not null default true
);

create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id) on delete cascade,
  plan_id uuid not null references plans(id),
  status text not null default 'pending' check (status in ('pending','active','expired','cancelled')),
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists payment_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles(id),
  subscription_id uuid references subscriptions(id),
  provider text not null default 'multicaixa_express',
  provider_reference text unique,
  amount_aoa integer not null check (amount_aoa > 0),
  status text not null default 'pending' check (status in ('pending','confirmed','failed','refunded')),
  confirmed_at timestamptz,
  raw_provider_event jsonb,
  created_at timestamptz not null default now()
);

create table if not exists competitions (
  id uuid primary key default gen_random_uuid(),
  provider_id text,
  name text not null,
  country text,
  season text
);

create table if not exists teams (
  id uuid primary key default gen_random_uuid(),
  provider_id text,
  name text not null,
  logo_url text
);

create table if not exists matches (
  id uuid primary key default gen_random_uuid(),
  provider_id text unique,
  competition_id uuid references competitions(id),
  home_team_id uuid references teams(id),
  away_team_id uuid references teams(id),
  kickoff timestamptz,
  status text not null default 'scheduled',
  home_score integer,
  away_score integer,
  source_updated_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists analyses (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references matches(id) on delete cascade,
  title text not null,
  body text not null,
  prediction text,
  confidence_label text,
  vip_only boolean not null default false,
  published boolean not null default false,
  author_id uuid references profiles(id),
  created_at timestamptz not null default now()
);

-- Segurança: activar RLS e criar políticas específicas antes de pôr em produção.
-- Nunca permitir ao cliente escrever status='confirmed' em payment_transactions
-- nem activar subscriptions directamente. Apenas o servidor de confiança pode fazê-lo.
